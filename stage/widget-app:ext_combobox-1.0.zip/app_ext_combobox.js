
Appcelerator.Widget.AppExtCombobox =
    {
    /**
     * The name of the widget
     */
    getName: function()
    {
        return 'app:ext_combobox';
    },
    /**
     * A description of what the widget does
     */
    getDescription: function()
    {
        //TODO
        return 'ExtJS Combo';
    },
    /**
     * The version of the widget. This will automatically be corrected when you
     * publish the widget.
     */
    getVersion: function()
    {
        return 1.0;
    },
    /**
     * The widget spec version.  This is used to maintain backwards compatability as the
     * Widget API needs to change.
     */
    getSpecVersion: function()
    {
        return 1.0;
    },
    /**
     * The widget author's full name (that's you)
     */
    getAuthor: function()
    {
        return 'Malcolm Wise';
    },
    /**
     * The URL for more information about the widget or the author.
     */
    getModuleURL: function ()
    {
        return 'http://www.appcelerator.org';
    },
    /**
     * This should always return true for widgets.
     */
    isWidget: function ()
    {
        return true;
    },
    /**
     * The widget's tag name
     */
    getWidgetName: function()
    {
        return 'app:ext_combobox';
    },
    /**
     * The attributes supported by the widget as attributes of the tag.  This metadata is 
     * important so that your widget can automatically be type checked, documented, 
     * so the IDE can auto-sense the widgets metadata for autocomplete, etc.
     */
    getAttributes: function()
    {
        var T = Appcelerator.Types;
        return [{name: 'on', optional: false, description: "Used to show combo", type: T.onExpr},
            {name: 'property', optional: false, description: "array data property", type: T.identifier},
            {name: 'applyTo', optional: false, description: "id of the input element to be used as the combo"},
            {name: 'allQuery', optional: true, description: "The text query to send to the server to return all records for the list with no filtering"},
            {name: 'selectMessage', optional: false, description: "message to send on item selected", type: T.messageSend},
            {name: 'displayField', optional: true, description: "display field"},
            {name: 'valueField', optional: true, description: "value field"},
            {name: 'height', optional: true, description: "height of combo", type: T.number},
            {name: 'width', optional: true, description: "width of combo", type: T.number},
            {name: 'listWidth', optional: true, description: "width of list", type: T.number},
            {name: 'typeAhead', optional: true, defaultValue: false, description: "populate and auto-select the remaining text being typed", type: T.bool},
            {name: 'editable', optional: true, defaultValue: true, description: "true to allow typing in the field", type: T.bool},
            {name: 'resizable', optional: true, defaultValue: false, description: "true to add a resize handle to the drop-down list", type: T.bool},
            {name: 'forceSelection', optional: true, defaultValue: false, description: "True to restrict the selected value to one of the values in the list", type: T.bool},
            {name: 'selectOnFocus', optional: true, defaultValue: false, description: "true to auto-select any existing text on focus", type: T.bool},
            {name: 'loadingText', optional: true, description: "Loading Text"},
            {name: 'emptyText', optional: true, description: "Initial text to display"},
            {name: 'mode', optional: true, description: "'remote' to load from the server or 'local'"},
            {name: 'tplElementId', optional: true, description: "id of a hidden textarea containing the html to be used in a custom template for rendering the list"},
            {name: 'itemSelector', optional: true, description: "CSS selector to use for the custom template"},
            {name: 'hideTrigger', optional: true, defaultValue: false, description: "show the drop-down arrow", type: T.bool},
            {name: 'triggerAction', optional: true, defaultValue: "query", description: "The action to execute when the trigger field is activated. Use 'all' to run the query specified by the allQuery config option"},
            {name: 'minChars', optional: true, description: "Minimum no. of characters to type before searching", type: T.number},
            {name: 'pageSize', optional: true, defaultValue: 0, description: "number of search result rows per page", type: T.number},
            {name: 'requestMessage', optional: true, description: "the request message to send for retrieving data", type: T.messageSend}

        ];
    },
	
    /**
     * return an array of condition names for the custom conditions the widget supports in
     * the widget's on expression.
     */
    getConditions: function()
    {
        /*
	      TODO: you can define a condition that can be used in the widgets on expression
	      by returning the name of the condition here.  For instance, if this method returns
	      
	          ['close'];
	          
	      then the on expresson 'on="close then l:closed"' is valid. You can fire one of 
	      these conditions by using:
	      
	          Appcelerator.Widget.fireWidgetCondition(<widget_id>, <condition_name>, <payload>);
	          
	      This feature removes the need to specify special attributes such as 'closeMessage'
         */
	    
        return [];
    },
	
    /**
     * return an array of function names for the actions the widget supports in the widget's 
     * on expression.
     */
    getActions: function()
    {
        /* 
		  TODO: you can define a widget action which can be called in the widget's on expression
		  by adding the name of the action here and then defining a function in this class with the 
		  same name. For example, for the action 'execute':
		
			 execute: function(id,params,data,scope)
			 {
			 }
			
		  You can then do something like:  
		  
		     <app:ext_combobox on="l:some.message then execute"></app:ext_combobox>
		  
		   and this method will be invoked on your widget.	
         */
        return ['execute','select'];
    },	
    /**
     * this method will be called after the widget has been built, the content replaced and available
     * in the DOM and when it is ready to be compiled.
     *
     * @param {object} params
     */
    compileWidget: function(params)
    {
        Ext.BLANK_IMAGE_URL = Appcelerator.WidgetPath+'common/images/extjs/default/s.gif';
        var pageSize = params['pageSize'] - 0;
        // build store
        var store = new Ext.ux.data.JsonStore({
            root:params['property'],
            totalProperty:'totalCount',
            fields:params['properties']
        });
		
        // build combo options
        var options={};
        options['store'] = store;
        if (params['allQuery']) {
            options['allQuery'] = params['allQuery'];
        }
        if (params['displayField']) {
            options['displayField'] = params['displayField'];
        }
        if (params['valueField']) {
            options['valueField'] = params['valueField'];
        }
        
        options['typeAhead'] = (params['typeAhead'] == "true")?true:false;
        options['editable'] = (params['editable'] == "false")?false:true;    
        options['resizable'] = (params['resizable'] == "true")?true:false;    
        options['forceSelection'] = (params['forceSelection'] == "true")?true:false;    
        options['selectOnFocus'] = (params['selectOnFocus'] == "true")?true:false;    
        options['hideTrigger'] = (params['hideTrigger'] == "true")?true:false;
        
        if (params['triggerAction']) {
            options['triggerAction'] = params['triggerAction'];
        }
        options['applyTo'] = params['applyTo'];
        if (params['height']) {
            options['height'] = params['height'] - 0;
        }
        if (params['width']) {
            options['width'] = params['width'] - 0;
        }
        if (params['listWidth']) {
            options['listWidth'] = params['listWidth'] - 0;
        }
        if(params['minChars']) {
            options['minChars'] = params['minChars'];
        }
        if (params['loadingText']) {
            options['loadingText'] = params['loadingText'];
        }
        if (params['emptyText']) {
            options['emptyText'] = params['emptyText'];
        }
        if (params['mode']) {
            options['mode'] = params['mode'];
        }
        options['pageSize'] = pageSize;
        if (params['tplElementId']) {
            var el = Ext.get(params['tplElementId']);
            var tpl = Ext.XTemplate.from(el);
            options['tpl'] = tpl;
            options['itemSelector'] = params['itemSelector']; 
        }
        // create the combo
        var combobox = new Ext.form.ComboBox(options);
	
        // store the datastore
        params['store'] = store;
        params['combobox'] = combobox;
		
        // setup listener for item being selected
        combobox.on('select', 
        function(combo,record,idx) {
            var payload = {};
            payload['rowidx'] = idx;
            for (var i=0;i<params['properties'].length;i++)
            {
                payload[params['properties'][i].name] = record.get(params['properties'][i].name);
            }
            $MQ(params['selectMessage'],payload);                
        }
    );
        store.on('beforeload',
        function(thisStore, opt) {
            if (!opt.params) {
                opt = params['opt'];
            }
            opt.params.query = thisStore.baseParams.query;
            params['opt'] = opt;
            $MQ(params['requestMessage'],opt);
            return false;
        })
    },
	
    execute: function(id,params,data,scope)  {
        params['store'].loadData(data,false);
        if (params['opt']) { 
            // fire load event with paging parameters so that paging toolbar gets updated
            params['store'].fireEvent('load', params['store'], [], params['opt']);
        }

    },

    select: function(id,params,data,scope,version,customActionArguments) {
            var value = eval("data." +customActionArguments[0].value);
            params['combobox'].setValue(value);
    },
    /**
     * this method will be called each time a <app:ext_combobox> is encountered in a page. the return object gives
     * instructions to the compiler about how to process the widget.
     *
     * @param {element} element for the <app:ext_combobox> encountered in the page
     * @param {object} parameters object for the attributes that <app:ext_combobox> supports
     */
    buildWidget: function(element,parameters)
    {
 
        var properties = [];
        if (Appcelerator.Browser.isIE)
        {
            // NOTE: in IE, you have to append with namespace
            var newhtml = element.innerHTML;
            newhtml = newhtml.replace(/<COLUMN/g,'<APP:COLUMN');
            newhtml = newhtml.replace(/\/COLUMN>/g,'/APP:COLUMN>');
            element.innerHTML = newhtml;
        }
        
        for (var c=0,len=element.childNodes.length;c<len;c++)   
        {
            var child = element.childNodes[c];
            if (child.nodeType == 1 && child.nodeName.toLowerCase() == 'column')
            {
                var propRow = {};
				
                // do property row
                propRow['name'] = child.getAttribute('property');
                propRow['type'] = (child.getAttribute('type') == null)?'string':child.getAttribute('type');				
                properties.push(propRow);
            }
        }
        parameters['properties'] = properties;
		
        return {
            'presentation' : '',
            'position' : Appcelerator.Compiler.POSITION_REPLACE,  // usually the default, could be POSITION_REMOVE to remove <app:ext_combobox> entirely
            'wire' : true,  // true to compile the contents of the presentation contents replaced above
            'compile' : true,  // true to call compileWidget once the HTML has been replaced and available in the DOM
            'parameters': parameters  // parameters object to pass to compileWidget
        };		
    }
};

/*
To load a custom widget CSS file - create a css file under the widget's css directory and 
reference it here. For example:
  
    Appcelerator.Widget.loadWidgetCSS('app:ext_combobox','mystyles.css');

To load a widget that has widget JS dependencies, place your JS files under the widget's js
directory and use registerWidgetWithJS. For example:

    Appcelerator.Widget.registerWidgetWithJS('app:ext_combobox',Appcelerator.Widget.AppExtCombobox,['a.js', 'b.js']);

You can require a common JS file (loaded under widgets/common/js) and load your widget once it's loaded.
For example:

	Appcelerator.Widget.requireCommonJS('scriptaculous/builder.js',function()
	{
	    Appcelerator.Widget.registerWidgetWithJS('app:ext_combobox',Appcelerator.Widget.AppExtLiveCombo,['a.js']);
	});

If you need two or more common JS files located under widgets/common/js then just pass an array to the above function.
For example:

	Appcelerator.Widget.requireCommonJS(['scriptaculous/builder.js', 'extjs/ext-base.js'],function()
	{
	    Appcelerator.Widget.registerWidgetWithJS('app:ext_combobox',Appcelerator.Widget.AppExtCombobox,['a.js']);
	});

 */

Appcelerator.Widget.loadWidgetCommonCSS("app:ext_combobox","extjs/xtheme-gray.css");
Appcelerator.Widget.loadWidgetCommonCSS("app:ext_combobox","extjs/ext-all.css");
Appcelerator.Widget.requireCommonJS("extjs/ext-base.js",function()
{
    Appcelerator.Widget.requireCommonJS("extjs/ext-all-debug.js", function() {
        Appcelerator.Widget.registerWithJS('app:ext_combobox',Appcelerator.Widget.AppExtCombobox,["JsonStore.js"]);
    });
});



