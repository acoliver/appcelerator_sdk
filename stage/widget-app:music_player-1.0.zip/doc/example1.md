Title: Simple Streaming Example

This is a simple example that uses the `<app:music_player>` to auto-play an MP3.

++example
<app:music_player src="http://media.libsyn.com/media/redmonk/riaweekly008.mp3"> 
</app:music_player>
--example
	
