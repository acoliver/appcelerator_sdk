Title: Simple Example

This is a simple example that uses the `<app:shadowbox>`. For more options, visit http://mjijackson.com/shadowbox/doc/usage.html

++example
<app:shadowbox src="http://www.appcelerator.com/images/faces/jeff.jpg" options="{overlayOpacity: 0.5}" title="My Cool Photo">
	Click here to view
</app:shadowbox>
--example