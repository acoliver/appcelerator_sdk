Title: Simple Example

This is a simple example that uses the `<app:split_box>`.
	
	<app:split_box>
	</app:split_box>
	
