package org.appcelerator.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.web.context.WebApplicationContext;

public class TestManagerServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private TestManager testManager;
    @SuppressWarnings("unchecked")
    @Override
    public void init(ServletConfig config) throws ServletException
    {
        super.init(config);
        ListableBeanFactory factory = (ListableBeanFactory) config.getServletContext().getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
        testManager = (TestManager) factory.getBean("testManager");
    }
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
    	String action = request.getParameter("action");
    	if ("reset".equals(action)) {
        	PrintWriter writer = response.getWriter();
        	writeHeader(writer,"reset");
        	testManager.reset();
        	writer.write("<result success=\"true\"/>");
        	writeFooter(writer,"reset");
    		
    	} else {
    		serviceTest(request, response);
    	}
    }
    private void serviceTest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
    	Iterator<Test> iterator = testManager.get().iterator();
    	PrintWriter writer = response.getWriter();
    	writeHeader(writer,"testresults");
    	while (iterator.hasNext()) {
    		Test test = iterator.next();
        	writer.write(toXml(test));
    	}
    	writeFooter(writer,"testresults");
    }
    public static String toXml(Test test) {
    	String result = "<test type=\"" + test.getType() + "\""
		+ " status=\"" + test.getStatus() + "\""
		+ " duration=\"" + test.getDuration() + "\""
		+ " start=\"" + test.getStart() + "\">"
		+ " <details>" + test.getDetails() + "</details>"
		+ "</test>";
    	return result;
    }
    private void writeFooter(PrintWriter writer, String tag) {
    	writer.write("</"+ tag+">");
    }
    private void writeHeader(PrintWriter writer, String tag) {
    	writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    	writer.write("<"+ tag+">");
    }
	public TestManager getTestManager() {
		return testManager;
	}
	public void setTestManager(TestManager testManager) {
		this.testManager = testManager;
	}

}
