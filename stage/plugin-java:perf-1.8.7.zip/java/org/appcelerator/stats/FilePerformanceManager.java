/**
 * This file is part of Appcelerator.
 *
 * Copyright (C) 2006-2008 by Appcelerator, Inc. All Rights Reserved.
 * For more information, please visit http://www.appcelerator.org
 *
 * Appcelerator is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package org.appcelerator.stats;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.appcelerator.dispatcher.visitor.DispatchVisitor;
import org.appcelerator.messaging.Message;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class FilePerformanceManager implements InitializingBean, DispatchVisitor, DisposableBean{
	public static Log LOG = LogFactory.getLog(FilePerformanceManager.class);
	private String delimiter=";";
	private String filename;
	private boolean append = true;
	private boolean writeHeader = false;
	
	private PrintWriter writer;
	private boolean initialized = false;
	public FilePerformanceManager() {
		LOG.info("hello" + System.getProperties());
	}
	public void writeHeader() {
		if (writeHeader)
			writer.println("name"+delimiter+"time"+delimiter+"startTime");
		writer.flush();
	}
	public void afterPropertiesSet() throws Exception {
		init();
	}
	private void init() throws IOException {
		if (initialized)
			return;
		initialized = true;
		File file = new File(filename);
		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}
		writer = new PrintWriter(new FileWriter(file, append));
		writeHeader();
	}
	public void destroy() throws Exception {
		writer.close();
	}
	public String getDelimiter() {
		return delimiter;
	}
	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename.replaceAll("\\$\\{app.webapp.root\\}", System.getProperty("app.webapp.root"));
	}
	public boolean isAppend() {
		return append;
	}
	public void setAppend(boolean append) {
		this.append = append;
	}
	public boolean isWriteHeader() {
		return writeHeader;
	}
	public void setWriteHeader(boolean writeHeader) {
		this.writeHeader = writeHeader;
	}
	public Statistic createStat(Message message) {
		return new StatisticImpl(message.getType());
	}
	public void publish(Statistic stat) {
		try {
			init();
		} catch (IOException e) {
			throw new RuntimeException("problem initializing performance manager",e);
		}
		stat.end();
		writer.println(stat.getName()+delimiter+stat.getTime()+delimiter+stat.getStartTime()+delimiter);
		writer.flush();
	}
	public void endVisit(Object obj, Message request, List<Message> responses) {
		publish((Statistic) obj);
	}
	public Object startVisit(Message request, List<Message> responses) {
		return createStat(request);
	}
	
}
