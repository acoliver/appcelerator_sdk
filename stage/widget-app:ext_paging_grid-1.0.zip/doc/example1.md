Title: Simple Example

This is a simple example that uses the `<app:ext_paging_grid>`.
	
	<app:ext_paging_grid on="r:test.response then execute" 
		property="rows" 
	  width=500
    height=700
	  title="My Paging Grid Panel"
    remoteSort="true"
    loadMask="true"
    pageSize=25
    viewConfig="{forceFit:true}"
		selectMessage="l:row.select" >
    requestMessage="r:test.request">
	   <column property="col4" sortable="true" defaultSort="true" defaultSortDir="asc" width="130">Col 4</column>
	   <column property="col5" sortable="true" width="130" hidden="true">Col 5</column>
	   <column property="col6" sortable="true" renderer="pctChange" width="130">Col 6</column>
	</app:ext_paging_grid>
	
To initially load the grid, the request can be of the following format:
      r:test.request[params:{start:0,limit:25}]}
where 'start' is the record number to start at and 'limit' is the number of records on each page (must be the same
as the pageSize parameter if specified - defaults to 20 if omitted).  Your service needs to retrieve a page at a
time.
If remote sorting is specified, your service must also return the records in the required sort order.  There will be
two additional parameters sent with the request:
      'sort' - the column name to sort by
      'dir' - the sort sequence, 'ASC' or 'DESC'  	

This examples uses a custom cell renderer.  Here's an example of how to write one:
	
	<script>
	function pctChange(val){
        if(val > 0){
            return '<span style="color:green;">' + val + '%</span>';
        }else if(val < 0){
            return '<span style="color:red;">' + val + '%</span>';
        }
        return val;
    }
	</script>

