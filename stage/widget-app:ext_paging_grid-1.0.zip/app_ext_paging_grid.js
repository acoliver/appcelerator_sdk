
Appcelerator.Widget.AppExtPagingGrid =
    {
    getName: function()
    {
        return 'appcelerator ext_paging_grid';
    },
    getDescription: function()
    {
        return 'ExtJS Grid Panel with paging made into an Appcelerator Widget';
    },
    getVersion: function()
    {
        return 1.1;
    },
    getSpecVersion: function()
    {
        return 1.0;
    },
    getAuthor: function()
    {
        return 'Malcolm Wise';
    },
    getModuleURL: function ()
    {
        return 'http://www.appcelerator.org';
    },
    isWidget: function ()
    {
        return true;
    },
    getWidgetName: function()
    {
        return 'app:ext_paging_grid';
    },
    getActions: function()
    {
        return ['execute'];
    },	

    getAttributes: function()
    {
        var T = Appcelerator.Types;
        return [{name: 'on', optional: false, description: "Used to show grid", type: T.onExpr},
            {name: 'property', optional: false, description: "array data property", type: T.identifier},
            {name: 'selectMessage', optional: true, description: "message to send on row selected", type: T.messageSend},
            {name: 'height', optional: true, defaultValue:400, description: "height of grid", type: T.number},
            {name: 'width', optional: true, defaultValue:400, description: "width of grid", type: T.number},
            {name: 'stripeRows', optional: true, defaultValue:true, description: "alternate row color", type: T.bool},
            {name: 'frame', optional: true, defaultValue:false, description: "place a border frame around grid", type: T.bool},
            {name: 'autoExpandColumn', optional: true, description: "column to expand to take up excess width"},
            {name: 'loadMask', optional: true,  defaultValue:false, description: "whether to display a mask when loading", type: T.bool},
            {name: 'title', optional: true, description: "grid title"},
            {name: 'pageSize', optional: true, defaultValue:20, description: "number of rows per page", type: T.number},
            {name: 'remoteSort', optional: true, defaultValue:false, description: "sort values on server", type: T.bool},
            {name: 'requestMessage', optional: false, description: "the request message to send for retrieving data", type: T.messageSend}

        ];
    },
    compileWidget: function(params) 
    {
        var pageSize = params['pageSize'] - 0;
        // build store
        var store = new Ext.ux.data.JsonStore({
            root:params['property'],
            totalProperty:'totalCount',
            fields:params['properties'],
            remoteSort:params['remoteSort']
        });
        store.setDefaultSort(params['defaultSortCol'], params['defaultSortDir']);
        var bbar = new Ext.PagingToolbar({
            pageSize: pageSize,
            store: store,
            displayInfo: true,
            displayMsg: 'Displaying records {0} - {1} of {2}',
            emptyMsg: "No records to display"
        });
		
        // build grid options
        var options={};
        options['store'] = store;
        options['columns'] = params['columns'];		
        options['frame'] = (params['frame'] == "true")?true:false;
        options['stripeRows'] = (params['stripeRows'] == "true")?true:false;
        options['renderTo'] = params['id'],
        options['width'] = params['width'];
        options['title'] = params['title'];
        options['height'] = params['height'];
        options['loadMask'] = params['loadMask'];
        options['viewConfig'] = params['viewConfig'];
        options['bbar'] = bbar;

        options['fitToFrame'] = true;

        if (params['autoExpandColumn'])
        {
            options['autoExpandColumn'] = params['autoExpandColumn'];
        }
        // create the grid
        var grid = new Ext.grid.GridPanel(options);
        grid.render();
	
        // store the datastore
        params['store'] = store;
		
        // if row selection message, setup listener
        if (params['selectMessage'])
        {
            grid.getSelectionModel().on('rowselect', 
            function(model,idx,data) {
                var payload = {};
                payload['rowidx'] = idx;
                for (var i=0;i<params['properties'].length;i++)
                {
                    payload["'"+params['properties'][i].name+"'"] = data.get(params['properties'][i].name);
                }
                $MQ(params['selectMessage'],payload);                
            }
        );
        }
        store.on('beforeload',
        function(thisStore, opt) {
            var sortState = thisStore.getSortState();
            if (!opt.params) {
                opt = params['opt'];
            }
            if (params['remoteSort'] && sortState.field) {
                opt.params.sort = sortState.field;
                opt.params.dir = sortState.direction;
            }
            params['opt'] = opt;
            $MQ(params['requestMessage'],opt);
            return false;
        })
    },

    execute: function(id,params,data,scope)  {
        params['store'].loadData(data,false);
        if (params['opt']) { 
            // fire load event with paging parameters so that paging toolbar gets updated
            params['store'].fireEvent('load', params['store'], [], params['opt']);
        } else {
            params['opt'] = {params:{start:0,limit:params['pageSize']}};
        }

    },

    buildWidget: function(element,parameters)
    {
        var id = Appcelerator.Compiler.generateId();
        var html = "<div id='"+ id+ "'></div>";
        parameters['id'] = id;
 
      	var columns = [];
        var properties = [];
        if (Appcelerator.Browser.isIE)
        {
            // NOTE: in IE, you have to append with namespace
            var newhtml = element.innerHTML;
            newhtml = newhtml.replace(/<COLUMN/g,'<APP:COLUMN');
            newhtml = newhtml.replace(/\/COLUMN>/g,'/APP:COLUMN>');
            element.innerHTML = newhtml;
        }
        
        var defaultSortCol;
        var defaultSortDir;
        for (var c=0,len=element.childNodes.length;c<len;c++)   
        {
            var child = element.childNodes[c];
            if (child.nodeType == 1 && child.nodeName.toLowerCase() == 'column')
            {
                var propRow = {};
                var colRow = {};
				
                // do property row
                propRow['name'] = child.getAttribute('property');
                propRow['type'] = (child.getAttribute('type') == null)?'string':child.getAttribute('type');				
                properties.push(propRow);
				
                // do column row
                if (parameters['autoExpandColumn'] == propRow['name'])
                {
                    colRow['id'] = propRow['name'];
                }
                colRow['header'] = child.innerHTML;
                colRow['width'] = (child.getAttribute('width')==null)?100:parseInt(child.getAttribute('width'));
                colRow['sortable'] = (child.getAttribute('sortable')=="true")?true:false;
                colRow['hidden'] = (child.getAttribute('hidden')=="true")?true:false;
                if (child.getAttribute('defaultSort')=="true") {
                    defaultSortCol = child.getAttribute('property');
                    defaultSortDir = child.getAttribute('defaultSortDir')==null?"asc":child.getAttribute('defaultSortDir');
                }
                colRow['dataIndex'] = propRow['name'];
				
                if (child.getAttribute('renderer'))
                {
                    colRow['renderer'] = window[child.getAttribute('renderer')];
                }
                columns.push(colRow);
				
            }
        }
        parameters['columns'] = columns;
        parameters['properties'] = properties;
        parameters['defaultSortCol'] = defaultSortCol;
        parameters['defaultSortDir'] = defaultSortDir;
		
        return {
            'presentation' :html ,
            'position' : Appcelerator.Compiler.POSITION_REPLACE,
            'parameters': parameters,
            'wire' : true,
            'compile':true
        };
    }
};
Appcelerator.Widget.loadWidgetCommonCSS("app:ext_paging_grid","extjs/xtheme-gray.css");
Appcelerator.Widget.loadWidgetCommonCSS("app:ext_paging_grid","extjs/ext-all.css");
Appcelerator.Widget.requireCommonJS("extjs/ext-base.js",function()
{
      Appcelerator.Widget.requireCommonJS("extjs/ext-all.js", function() {
          Appcelerator.Widget.registerWithJS('app:ext_paging_grid',Appcelerator.Widget.AppExtPagingGrid,["JsonStore.js"]);
      });
});
