Title: Simple Example

This is a simple example that uses the `<app:panel>`.

++example
<app:panel header_text="Free Macallan" color="light_gray" width="300px" rounded="true" close="true" shade="true" draggable="true">
    <html:img src="widgets/app_panel/doc/macallan.gif"></html:img>                
    <html:h4>While supplies last!</html:h4>
</app:panel>
--example

	
