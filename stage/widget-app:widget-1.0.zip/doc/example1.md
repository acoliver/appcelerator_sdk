Title: Simple Example

This is a simple example that uses the `<app:widget>`.

++example	
<app:widget name="app:my_widget">
    Put anything you want in here
</app:widget>

<app:my_widget>
    This content will be replaced by what was above
</app:my_widget>
--example
