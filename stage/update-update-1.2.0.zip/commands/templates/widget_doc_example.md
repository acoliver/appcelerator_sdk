Title: Simple Example

This is a simple example that uses the `<NAME>`.
	
	<NAME>
	</NAME>
	
