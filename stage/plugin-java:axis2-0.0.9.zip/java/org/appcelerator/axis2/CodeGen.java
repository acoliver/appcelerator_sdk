package org.appcelerator.axis2;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.axis2.client.Stub;

public class CodeGen {
	private File sourcedirectory;
	private String targetpackage;
	private File targetdir;

	public CodeGen(String sourcedirectory, String targetpackage, String targetdir) {
		super();
		this.sourcedirectory = new File(sourcedirectory);
		this.targetpackage = targetpackage;
		this.targetdir = new File(targetdir);
	}

	public static void main(String args[]) throws Exception {
		CodeGen codegen = new CodeGen(args[0], args[1], args[2]);
		codegen.generateJarsource();
	}

	private Class[] scanclasses() {
		ArrayList<Class> classes = new ArrayList<Class>();
		scandir(Stub.class, this.sourcedirectory, classes);
		return classes.toArray(new Class[classes.size()]);
	}

	public void scandir(Class childof, File dir, ArrayList<Class> classes) {
		for (String filename : dir.list()) {
			File file = new File(dir.getAbsolutePath() + "/" + filename);
			if (file.isDirectory())
				scandir(childof, file, classes);
			else {
				try {
					Class clazz = getclass(file, sourcedirectory);
					if (clazz != null && childof.isAssignableFrom(clazz))
						classes.add(clazz);
				} catch (Exception squash) {
					System.out.println("nogood " + filename + " " + squash);
				}
			}
		}
	}

	private Class getclass(File file, File sourcedirectory2) throws ClassNotFoundException {
		String classname = file.getAbsolutePath().substring(sourcedirectory2.getAbsolutePath().length() + 1);
		if (!classname.endsWith(".java"))
			return null;
		classname = classname.replace("/", ".");
		classname = classname.replace("\\", ".");
		classname = classname.substring(0, classname.length() - 5);
		if (!classname.endsWith("Stub"))
			return null;
		Class clazz = Class.forName(classname);
		return clazz;
	}

	private String serviceClassname(Class stub) {
		String name = stub.getSimpleName();
		int end = name.indexOf("ServiceStub");
		String stripped = name.substring(0, end);
		return stripped + "Service";
	}

	public void generateJarsource() throws Exception {
		File targetpackagedir = new File(targetdir, targetpackage.replace(".", "/"));
		targetpackagedir.mkdirs();
		for (Class stub : scanclasses()) {
			String serviceclass = serviceClassname(stub);
			File classfile = new File(targetpackagedir, serviceclass + ".java");
			FileOutputStream os = new FileOutputStream(classfile);
			PrintWriter writer = new PrintWriter(os);
			writeClassHeader(writer, serviceclass);
			for (AxisServiceAdapter adapter : AxisServiceDispatcher.add(stub, "", false, null)) {
				generateMethod(adapter, writer);
			}
			writeClassFooter(writer);
			os.flush();
			os.close();
		}
	}

	public void generateMethod(AxisServiceAdapter adapter, PrintWriter writer) {
		HashMap<String, String> params = new HashMap<String,String>();
		params.put("paramclass", adapter.getParamclass().getName().replace("$", "."));
		params.put("request", adapter.getRequest());
		params.put("response", adapter.getResponse());
		params.put("methodname", adapter.getMethod().getName());
		params.put("stubclass", adapter.getMethod().getDeclaringClass().getName());
		params.put("resultclass", adapter.getMethod().getReturnType().getName().replace("$", "."));

		String result = "\t@Service(request = \"#{request}\", response = \"#{response}\")\n"
				+ "\tpublic void #{methodname}(Message request, Message response) throws Exception {\n" 
				+ "\t\t#{paramclass} axisobject = (#{paramclass}) AxisUtil.toAxisObject(request, #{paramclass}.class);\n"
				+ "\t\t#{resultclass} result = new #{stubclass}().#{methodname}(axisobject);\n"
				+ "\t\tAxisUtil.toMessageDataObject(result, response.getData());\n" + "\t}\n";
		for(String name : params.keySet()) {
			result = result.replace("#{"+name+"}", params.get(name));
		}
		writer.write(result);
	}

	public void writeClassHeader(PrintWriter writer, String classname) {
		HashMap<String, String> params = new HashMap<String,String>();
		params.put("targetpackage", targetpackage);
		params.put("classname", classname);
		String result = "package #{targetpackage};\n\n" 
				+ "import org.appcelerator.annotation.Service;\n" 
				+ "import org.appcelerator.axis2.AxisUtil;\n"
				+ "import org.appcelerator.messaging.Message;\n\n" 
				+ "public class #{classname} {\n\n";
		for(String name : params.keySet()) {
			result = result.replace("#{"+name+"}", params.get(name));
		}
		writer.write(result);
		writer.flush();
	}

	public void writeClassFooter(PrintWriter writer) {
		String footer = "}";
		writer.write(footer);
		writer.flush();
	}
}
