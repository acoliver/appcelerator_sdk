package org.appcelerator.axis2;

import java.lang.reflect.Method;
import java.util.ArrayList;

import org.appcelerator.dispatcher.ServiceRegistry;


public class AxisServiceDispatcher {
	public static AxisServiceAdapter add(Method method, String url, boolean register, Object endpoint) throws Exception {
		String paramname = "param";
		AxisServiceAdapter adapter = new AxisServiceAdapter(method, paramname, "result", endpoint, method.getName()+".request", method.getName()+".response", "1.0",url);
		if (register)
			ServiceRegistry.registerService(adapter, true);
		return adapter;
	}
	

	public static AxisServiceAdapter add(Method method, String url, boolean register) throws Exception {
		Class stub = method.getDeclaringClass();
		Object endpoint = AxisUtil.getEndpoint(stub, url);
		return add(method,url,register,endpoint);
	}
	public void init() throws Exception {
		//pass in class or discover classes from the jar thats created
		//prompt for url, 
		//could potentially provide mappings for method to requestprop, resultprop, requesttype, responsetype
//		add(QueryServiceStub.class, "http://LODVM1044:8080/axis/services/QueryPort", true);
	}
	public static AxisServiceAdapter[] add(Class clazz, String url, boolean register, Object endpoint) throws Exception {
		ArrayList<AxisServiceAdapter> adapters = new ArrayList<AxisServiceAdapter>();
		for (Method method : getMethods(clazz)) {
			try {
				AxisServiceAdapter adapter = add(method, url, register, endpoint);
				adapters.add(adapter);
			} catch (Exception squash) {
				
			}
		}
		return adapters.toArray(new AxisServiceAdapter[adapters.size()]);
	}
	public static AxisServiceAdapter[] add(Class clazz, String url, boolean register) throws Exception {
		ArrayList<AxisServiceAdapter> adapters = new ArrayList<AxisServiceAdapter>();
		for (Method method : getMethods(clazz)) {
			try {
				AxisServiceAdapter adapter = add(method, url, register);
				adapters.add(adapter);
			} catch (Exception squash) {
				
			}
		}
		return adapters.toArray(new AxisServiceAdapter[adapters.size()]);
	}
	private static Method[] getMethods(Class stub) {
		ArrayList<Method> result = new ArrayList<Method>();
		for (Method method : stub.getMethods()) {
			if (method.getName().startsWith("start") || method.getName().startsWith("equals")|| method.getName().startsWith("wait") || method.getName().startsWith("_setServiceClient"))
				continue;
			result.add(method);
		}
		return result.toArray(new Method[result.size()]);
	}
}
