package org.appcelerator.axis2;

import java.lang.reflect.Method;

import org.appcelerator.dispatcher.ServiceAdapter;
import org.appcelerator.messaging.Message;

public class AxisServiceAdapter extends ServiceAdapter {
	private Method method;
	private String parametername;
	private String resultpropertyname;
	private Object endpoint;
	private Class paramclass;
	private String url;
	public AxisServiceAdapter(Method method, String parametername, String resultpropertyname, Object endpoint, String request, String response, String version, String url) {
		super();
		this.method = method;
		this.parametername = parametername;
		this.resultpropertyname = resultpropertyname;
		this.endpoint = endpoint;
		this.paramclass = method.getParameterTypes()[0];
		this.request = request;
		this.response = response;
		this.version = version;
		this.url = url;
	}
	@Override
	public void dispatch(Message request, Message response) {
		try {
			Object axisparam = AxisUtil.toAxisObject(request, paramclass, parametername);
			Object result = method.invoke(endpoint, axisparam);
			AxisUtil.toMessageDataObject(result, response.getData(), resultpropertyname);
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			response.getData().put("success", false);
			response.getData().put("exception", e.getMessage());
		}
	}

	public boolean is(ServiceAdapter sa) {
		if (!(sa instanceof AxisServiceAdapter)) {
			return false;
		}

		AxisServiceAdapter target = (AxisServiceAdapter) sa;
		if (this.method.equals(target.method)) {
			return true;
		}

		return false;
	}

	public boolean equals(Object obj) {
		if (obj instanceof AxisServiceAdapter) {
			AxisServiceAdapter sa = (AxisServiceAdapter) obj;
			return sa.method.equals(method) && super.equals(obj);
		}
		return false;
	}

	public int hashCode() {
		return this.method.hashCode() ^ super.hashCode();
	}
	public Method getMethod() {
		return method;
	}
	public void setMethod(Method method) {
		this.method = method;
	}
	public String getParametername() {
		return parametername;
	}
	public void setParametername(String parametername) {
		this.parametername = parametername;
	}
	public String getResultpropertyname() {
		return resultpropertyname;
	}
	public void setResultpropertyname(String resultpropertyname) {
		this.resultpropertyname = resultpropertyname;
	}
	public Object getEndpoint() {
		return endpoint;
	}
	public void setEndpoint(Object endpoint) {
		this.endpoint = endpoint;
	}
	public Class getParamclass() {
		return paramclass;
	}
	public void setParamclass(Class paramclass) {
		this.paramclass = paramclass;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
}
