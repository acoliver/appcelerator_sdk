package org.appcelerator.axis2;
import java.lang.reflect.InvocationTargetException;

import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import net.sf.json.JsonConfig;

import org.apache.axis2.AxisFault;
import org.apache.axis2.databinding.types.IDRef;
import org.apache.axis2.databinding.types.Id;
import org.appcelerator.messaging.IMessageDataObject;
import org.appcelerator.messaging.Message;


public class AxisUtil {
	public static JsonConfig getDefaultConfig() {
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.registerJsonValueProcessor(Id.class, new AxisIdValueProcessor());
		jsonConfig.registerJsonValueProcessor(IDRef.class, new AxisIdRefValueProcessor());
		return jsonConfig;
	}
	public static void toMessageDataObject(Object axisobject, IMessageDataObject into) {
		toMessageDataObject(axisobject, into, null, getDefaultConfig());
	}
	public static void toMessageDataObject(Object axisobject, IMessageDataObject into, String name) {
		toMessageDataObject(axisobject, into, name, getDefaultConfig());
	}
	public static void toMessageDataObject(Object axisobject, IMessageDataObject into, String name, JsonConfig jsonConfig) {
		JSONObject obj = toJSONObject(axisobject, jsonConfig);
		if (name==null || name.equals(""))
			merge(obj, into);
		else
			into.put(name, obj);
	}
	public static void merge(JSONObject from, IMessageDataObject intomessage) {
		String [] keys = (String[]) from.keySet().toArray(new String[from.keySet().size()]);
		for (String key : keys) {
			Object value = from.get(key);
			intomessage.put(key, value);
		}
	}
	public static JSONObject toJSONObject(Object axisobject) {
		return toJSONObject(axisobject,getDefaultConfig());
	}
	public static JSONObject toJSONObject(Object axisobject, JsonConfig jsonConfig) {
		return JSONObject.fromObject(axisobject, jsonConfig);
	}
	public static Object toAxisObject(Message requestMessage, Class beanclass) throws Exception {
		return toAxisObject(requestMessage.getData(),beanclass,"");
	}
	public static Object toAxisObject(Message requestMessage, Class beanclass, String name) throws Exception {
		return toAxisObject(requestMessage.getData(), beanclass, name);
	}
	public static Object toAxisObject(IMessageDataObject request, Class axisbeanclass, String name) throws Exception {
		String json = null;
		if (name=="")
			json = request.toDataString();
		else
			json = request.getObject(name).toDataString();
		Object toparam = toAxisObject(axisbeanclass, json);
		return toparam;
	}
	public static Object toAxisObject(Class axisbeanclass, String json) throws NoSuchMethodException {
		JsonConfig jsonConfig =  new JsonConfig();
		jsonConfig.setRootClass( axisbeanclass );
		JSONObject jsonobj = JSONObject.fromObject(json);
		return JSONSerializer.toJava( jsonobj, jsonConfig );
	}
	public static Object getEndpoint(Class clazz, String url) throws AxisFault, IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		Object endpoint = null;
		if (url==null || url.equals(""))
			endpoint =  clazz.newInstance();
		else
			endpoint =  clazz.getDeclaredConstructor(String.class).newInstance(url);
		return endpoint;
	}

}
