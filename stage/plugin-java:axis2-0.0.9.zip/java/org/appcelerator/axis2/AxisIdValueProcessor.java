package org.appcelerator.axis2;

import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonValueProcessor;

import org.apache.axis2.databinding.types.Id;

public class AxisIdValueProcessor implements JsonValueProcessor {
	public Object processArrayValue(Object value, JsonConfig jsonConfig) {
		return null;
	}

	public Object processObjectValue(String key, Object value, JsonConfig jsonConfig) {
		Id id = (Id)value;
		JSONObject obj = new JSONObject();
		obj.put("value", id.toString());
		return obj;
	}

}
