require 'fileutils'
# This file is part of Appcelerator.
#
# Copyright (C) 2006-2008 by Appcelerator, Inc. All Rights Reserved.
# For more information, please visit http://www.appcelerator.org
#
# Appcelerator is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

include Appcelerator
class Axis2Plugin < Appcelerator::Plugin
  def plugin_registered
    CommandRegistry.registerCommand('gen:axis2',
    'generate the axis stubs and appcelerator services from a wsdl', [
      {
        :name=>'path',
        :help=>'directory to run in, defaults to working directory',
        :required=>false,
        :default=>nil,
        :type=>[
          Appcelerator::Types::FileType,
          Appcelerator::Types::DirectoryType,
          Appcelerator::Types::AlphanumericType
        ],
        :conversion=>Appcelerator::Types::DirectoryType
      }
    ],[
      {
         :name=>'wsdl',
         :display=>'--wsdl=wsdl',
         :help=>'the url for the wsdl.',
         :default=>'',
         :value=>true
      },
      {
        :name=>'axispackage',
        :display=>'--axispackage=com.xxx',
        :help=>'the target package for the axis stub.',
        :default=>'my.axis',
        :value=>true
      },
      {
        :name=>'axisdir',
        :display=>'--axisdir=com.xxx',
        :help=>'the target directory for the axis source code.',
        :default=>'src/axissource',
        :value=>true
      },
      {
        :name=>'axisdist',
        :display=>'--axisdist=lib/axisstub',
        :help=>'the directory to copy the axis stub jar to.',
        :default=>'lib/axis2stub',
        :value=>true
      },
      {
          :name=>'appcpackage',
          :display=>'--appcpackage=com.xxx',
          :help=>'the target package for the appcelerator services.',
          :default=>'my.service',
          :value=>true
      },
      {
        :name=>'appcdir',
        :display=>'--appcdir=com.xxx',
        :help=>'the target directory for the appcelerator source code.',
        :default=>'app/services',
        :value=>true
      },
      {
        :name=>'silent',
        :display=>'--silent=true',
        :help=>'whether to run the command silent or not.',
        :default=>false,
        :value=>true
      }
      
    ],
    nil,
    :project) do |args,options|
      if options[:silent]=='false' || options[:silent]==false
        options[:wsdl] = prompt("Whats the url for your wsdl?",options[:wsdl])
        options[:axisdir] = prompt("What directory do you want to use for storing the axis stubs?",options[:axisdir])
        options[:axispackage] = prompt("What package name do you want to use for your axis stubs?",options[:axispackage])
        options[:appcdir] = prompt("What directory do you want to generate the services to?",options[:appcdir])
        options[:appcpackage] = prompt("What package name do you want to use for your appcelerator services?",options[:appcpackage])
      end
      ensure_env "JAVA_HOME"
      ensure_env "AXIS2_HOME"
      process(options)
    end
  end
  def ensure_env(name)
    if ENV[name].nil?
      puts "you must have #{name} environment variable set"
      exit 0
    end
  end
  def process(options)
    java_path_separator = separator()
    FileUtils.mkdir_p options[:axisdir] unless File.exist? options[:axisdir]
    FileUtils.cd options[:axisdir] do |dir|
      scriptfile = script("wsdl2java")
      result = system "#{ENV['AXIS2_HOME']}/bin/#{scriptfile} -uri #{options[:wsdl]} -p #{options[:axispackage]} -t"
      exit(0) unless result==true
      result = call_command("ant jar.client")
      exit(0) unless result==true
    end
    targetdir_path = File.expand_path(options[:axisdir])
    appctarget_path = wrapfilename("#{File.expand_path(options[:appcdir])}")
    axisdist_path = File.expand_path(options[:axisdist])
    targetdir_src = wrapfilename("#{targetdir_path}/src")
    
    FileUtils.mkdir_p axisdist_path unless File.exist? axisdist_path
    FileUtils.cd("lib") do |dir|
      cp = Dir["**/*.jar"].inject([]) {|a,f| a<<wrapfilename(f) }
      cp.push wrapfilename("../stage/lib/cmdb-1.0.0.jar")
      cp3 = Dir["#{targetdir_path}/build/lib/*.jar"].inject([]) {|a,f| a<<wrapfilename(f) }
      FileUtils.cp(cp3, axisdist_path)
      cp = cp.concat(cp3)
      call_command "java -cp #{cp.join(java_path_separator)} org.appcelerator.axis2.CodeGen #{targetdir_src} #{options[:appcpackage]} #{appctarget_path}"
    end
  end
  def prompt(message, default="")
    if default==""
      puts "#{message}"
    else
      puts "#{message} [#{default}]"
    end
    answer = ''
    while true
      ch = STDIN.getc
      break if ch==10
      answer << ch
    end
    if answer==''
      default
    else
      answer
    end
  end
  def wrapfilename(file)
    if file.index(" ").nil?
      towin32(file)
    else
      '"'+towin32(file)+'"'
    end
  end
  def towin32(path)
    case Config::CONFIG['target_os']
      when /(windows|win32)/
        return path.gsub("/","\\")
    end
    return path
  end
  def script(base)
    case Config::CONFIG['target_os']
      when /darwin/
        return "#{base}.sh"
      when /linux/
        return "#{base}.sh"
      when /(windows|win32)/
        return "#{base}.bat"
    end
  end
  def separator
    case Config::CONFIG['target_os']
      when /darwin/
        return ":"
      when /linux/
        return ":"
      when /(windows|win32)/
        return ";"
    end
  end
  def call_command(cmd)
    if is_win32
      cmd= "cmd.exe /c #{cmd}"
      result = system(cmd)
      if !result
        puts "failed running #{cmd}"
        puts "#{$2}"
      end
      result
    else
      system cmd
    end
  end
  def is_win32
    !is_unix
  end
  def is_unix
    result = (Config::CONFIG['target_os'] =~ /(windows|win32|mswin32)/).nil?
  end
end