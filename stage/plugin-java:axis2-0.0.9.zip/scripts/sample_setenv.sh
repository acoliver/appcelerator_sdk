export AXIS2_HOME=/Users/azuercher/workspace/axis2-1.4/
export JAVA_HOME=/System/Library/Frameworks/JavaVM.framework/Versions/1.5.0/Home/
export PATH=$PATH:/Users/azuercher/workspace/axis2-1.4/bin
export ANT_HOME=/usr/share/ant