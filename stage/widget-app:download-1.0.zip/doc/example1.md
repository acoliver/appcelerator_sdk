Title: Simple Example

This is a simple example that uses the `<app:download>`.
	
	<app:download>
	</app:download>
	
