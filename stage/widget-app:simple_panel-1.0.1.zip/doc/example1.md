Title: Simple Example

This is a simple example that uses the `<app:simple_panel>`.
	
++example
<app:simple_panel color="minty_fresh">
    <html:p style="margin: 0px">See, it's very simple</html:p>
</app:simple_panel>
--example

Another color:

++example
<app:simple_panel color="new_grass">
    <html:p style="margin: 0px">See, it's very simple</html:p>
</app:simple_panel>
--example