<?php
require_once 'Zend/Dojo/Exception.php';

class Zend_Dojo_View_Exception extends Zend_Dojo_Exception
{
}
