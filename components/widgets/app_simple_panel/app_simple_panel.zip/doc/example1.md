Title: Simple Example

This is a simple example that uses the `<app:simple_panel>`.
	
	<app:simple_panel>
	</app:simple_panel>
	
